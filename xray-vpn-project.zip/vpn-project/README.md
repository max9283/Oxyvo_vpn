# Xray VPN: сервер + Android-клиент

VPN на базе **Xray-core** (VLESS + Reality). Всё собирается в GitHub Actions — локально ставить Go/Android SDK не нужно.

## Структура

| Папка | Что внутри |
|---|---|
| `server/` | `vpnpanel` — панель выдачи ключей (Go, без зависимостей) и `install.sh` (ставит Xray + панель) |
| `core/` | Ядро для Android: Xray-core + tun2socks, собирается через `gomobile` в `vpncore.aar` |
| `android/` | Android-приложение (Kotlin, `VpnService`), использует `vpncore.aar` |
| `.github/workflows/build.yml` | Сборка серверных бинарников, AAR и APK |

## Как собрать на GitHub

1. Создайте репозиторий и залейте содержимое этой папки.
2. Откройте вкладку **Actions** — сборка запустится сама (или Run workflow).
3. Скачайте артефакты:
   - `vpn-server-amd64` / `vpn-server-arm64` — архив для сервера
   - `xray-vpn-apk` — установочный APK
   - `vpncore-aar` — само ядро

## Установка сервера (Ubuntu/Debian, root)

```bash
tar xzf vpn-server-amd64.tar.gz
bash install.sh your.domain.or.ip
```

Скрипт поставит Xray, сгенерирует ключи Reality, поднимет панель на `127.0.0.1:8080` и выведет админ-токен.

Создать пользователя:

```bash
curl -X POST -H "Authorization: Bearer <ADMIN_TOKEN>" \
     -d '{"name":"user1"}' http://127.0.0.1:8080/api/users
```

В ответе будет `vless://...` — вставьте её в Android-приложение и нажмите «Подключить».

Другие запросы: `GET /api/users`, `DELETE /api/users/<name>`, публичная ссылка `GET /sub/<token>`.

## Важно

- Код написан без возможности его скомпилировать в моей среде (нет доступа к сети), поэтому первая сборка в Actions может потребовать мелких правок — особенно в `core/` (версии зависимостей Xray/tun2socks меняют API). Пришлите лог ошибки, поправим.
- Панель слушает только localhost. Наружу её не открывайте без HTTPS; используйте SSH-туннель.
- APK подписан debug-ключом. Для публикации в Google Play нужна своя подпись.
- Соблюдайте законы вашей страны и правила хостинга при эксплуатации VPN-сервиса.
