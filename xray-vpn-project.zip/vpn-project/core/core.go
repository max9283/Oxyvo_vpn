// Package vpncore — ядро для Android: Xray-core + tun2socks.
// Собирается через gomobile bind в vpncore.aar.
//
// Схема: Android TUN fd -> tun2socks -> SOCKS5 127.0.0.1:10808 (inbound Xray) -> VLESS+Reality -> сервер.
package vpncore

import (
	"bytes"
	"errors"
	"fmt"
	"sync"

	"github.com/xjasonlyu/tun2socks/v2/engine"
	"github.com/xtls/xray-core/core"
	"github.com/xtls/xray-core/infra/conf/serial"
	_ "github.com/xtls/xray-core/main/distro/all"
)

const socksAddr = "socks5://127.0.0.1:10808"

var (
	mu      sync.Mutex
	xray    *core.Instance
	running bool
)

// Start запускает Xray с JSON-конфигом и tun2socks на переданном дескрипторе TUN.
func Start(configJSON string, tunFd int, mtu int) error {
	mu.Lock()
	defer mu.Unlock()
	if running {
		return errors.New("ядро уже запущено")
	}

	conf, err := serial.LoadJSONConfig(bytes.NewReader([]byte(configJSON)))
	if err != nil {
		return fmt.Errorf("конфиг Xray: %w", err)
	}
	inst, err := core.New(conf)
	if err != nil {
		return fmt.Errorf("создание Xray: %w", err)
	}
	if err := inst.Start(); err != nil {
		return fmt.Errorf("запуск Xray: %w", err)
	}

	engine.Insert(&engine.Key{
		MTU:      mtu,
		Proxy:    socksAddr,
		Device:   fmt.Sprintf("fd://%d", tunFd),
		LogLevel: "warn",
	})
	engine.Start()

	xray = inst
	running = true
	return nil
}

// Stop останавливает tun2socks и Xray.
func Stop() {
	mu.Lock()
	defer mu.Unlock()
	if !running {
		return
	}
	engine.Stop()
	if xray != nil {
		_ = xray.Close()
		xray = nil
	}
	running = false
}

// IsRunning сообщает, запущено ли ядро.
func IsRunning() bool {
	mu.Lock()
	defer mu.Unlock()
	return running
}
