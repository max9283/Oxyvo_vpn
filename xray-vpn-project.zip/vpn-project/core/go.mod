module vpncore

go 1.23
