// vpnpanel — минимальная панель выдачи ключей для Xray (VLESS + Reality).
// Только стандартная библиотека Go.
package main

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"strings"
	"sync"
)

type Settings struct {
	Listen      string `json:"listen"`
	AdminToken  string `json:"admin_token"`
	Host        string `json:"host"`
	Port        int    `json:"port"`
	PublicKey   string `json:"public_key"`
	ShortID     string `json:"short_id"`
	SNI         string `json:"sni"`
	XrayConfig  string `json:"xray_config"`
	UsersFile   string `json:"users_file"`
	XrayService string `json:"xray_service"`
}

type User struct {
	Name  string `json:"name"`
	UUID  string `json:"uuid"`
	Token string `json:"token"`
}

var (
	cfg   Settings
	mu    sync.Mutex
	users []User
)

func randHex(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		log.Fatal(err)
	}
	return fmt.Sprintf("%x", b)
}

func newUUID() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		log.Fatal(err)
	}
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:])
}

func loadSettings(path string) {
	data, err := os.ReadFile(path)
	if err != nil {
		log.Fatalf("не могу прочитать настройки: %v", err)
	}
	if err := json.Unmarshal(data, &cfg); err != nil {
		log.Fatalf("ошибка в настройках: %v", err)
	}
	if cfg.Listen == "" {
		cfg.Listen = "127.0.0.1:8080"
	}
	if cfg.XrayService == "" {
		cfg.XrayService = "xray"
	}
}

func loadUsers() {
	data, err := os.ReadFile(cfg.UsersFile)
	if err != nil {
		users = []User{}
		return
	}
	_ = json.Unmarshal(data, &users)
}

func saveUsers() error {
	data, _ := json.MarshalIndent(users, "", "  ")
	return os.WriteFile(cfg.UsersFile, data, 0o600)
}

// syncXray переписывает список клиентов в конфиге Xray и перезапускает сервис.
func syncXray() error {
	data, err := os.ReadFile(cfg.XrayConfig)
	if err != nil {
		return err
	}
	var conf map[string]any
	if err := json.Unmarshal(data, &conf); err != nil {
		return err
	}
	clients := make([]any, 0, len(users))
	for _, u := range users {
		clients = append(clients, map[string]any{
			"id":    u.UUID,
			"flow":  "xtls-rprx-vision",
			"email": u.Name,
		})
	}
	inbounds, _ := conf["inbounds"].([]any)
	found := false
	for _, ib := range inbounds {
		m, ok := ib.(map[string]any)
		if !ok || m["tag"] != "vless-in" {
			continue
		}
		settings, _ := m["settings"].(map[string]any)
		if settings == nil {
			settings = map[string]any{}
			m["settings"] = settings
		}
		settings["clients"] = clients
		found = true
	}
	if !found {
		return fmt.Errorf("inbound vless-in не найден в %s", cfg.XrayConfig)
	}
	out, _ := json.MarshalIndent(conf, "", "  ")
	if err := os.WriteFile(cfg.XrayConfig, out, 0o644); err != nil {
		return err
	}
	return exec.Command("systemctl", "restart", cfg.XrayService).Run()
}

func link(u User) string {
	q := url.Values{}
	q.Set("encryption", "none")
	q.Set("flow", "xtls-rprx-vision")
	q.Set("security", "reality")
	q.Set("sni", cfg.SNI)
	q.Set("fp", "chrome")
	q.Set("pbk", cfg.PublicKey)
	q.Set("sid", cfg.ShortID)
	q.Set("type", "tcp")
	return fmt.Sprintf("vless://%s@%s:%d?%s#%s", u.UUID, cfg.Host, cfg.Port, q.Encode(), url.PathEscape(u.Name))
}

func isAdmin(r *http.Request) bool {
	h := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	return subtle.ConstantTimeCompare([]byte(h), []byte(cfg.AdminToken)) == 1
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func main() {
	path := "/etc/vpnpanel/settings.json"
	if len(os.Args) > 1 {
		path = os.Args[1]
	}
	loadSettings(path)
	loadUsers()

	mux := http.NewServeMux()

	mux.HandleFunc("POST /api/users", func(w http.ResponseWriter, r *http.Request) {
		if !isAdmin(r) {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		var body struct {
			Name string `json:"name"`
		}
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil || strings.TrimSpace(body.Name) == "" {
			http.Error(w, "нужно поле name", http.StatusBadRequest)
			return
		}
		mu.Lock()
		defer mu.Unlock()
		for _, u := range users {
			if u.Name == body.Name {
				http.Error(w, "такой пользователь уже есть", http.StatusConflict)
				return
			}
		}
		u := User{Name: body.Name, UUID: newUUID(), Token: randHex(16)}
		users = append(users, u)
		if err := saveUsers(); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		if err := syncXray(); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		writeJSON(w, http.StatusCreated, map[string]string{
			"name": u.Name, "uuid": u.UUID, "link": link(u), "sub": "/sub/" + u.Token,
		})
	})

	mux.HandleFunc("GET /api/users", func(w http.ResponseWriter, r *http.Request) {
		if !isAdmin(r) {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		mu.Lock()
		defer mu.Unlock()
		writeJSON(w, http.StatusOK, users)
	})

	mux.HandleFunc("DELETE /api/users/{name}", func(w http.ResponseWriter, r *http.Request) {
		if !isAdmin(r) {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		name := r.PathValue("name")
		mu.Lock()
		defer mu.Unlock()
		kept := users[:0]
		removed := false
		for _, u := range users {
			if u.Name == name {
				removed = true
				continue
			}
			kept = append(kept, u)
		}
		if !removed {
			http.Error(w, "не найден", http.StatusNotFound)
			return
		}
		users = kept
		if err := saveUsers(); err == nil {
			err = syncXray()
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
		}
		w.WriteHeader(http.StatusNoContent)
	})

	// Публичная ссылка-подписка: приложение/пользователь получает vless:// ссылку.
	mux.HandleFunc("GET /sub/{token}", func(w http.ResponseWriter, r *http.Request) {
		t := r.PathValue("token")
		mu.Lock()
		defer mu.Unlock()
		for _, u := range users {
			if subtle.ConstantTimeCompare([]byte(u.Token), []byte(t)) == 1 {
				w.Header().Set("Content-Type", "text/plain; charset=utf-8")
				fmt.Fprint(w, link(u))
				return
			}
		}
		http.NotFound(w, r)
	})

	log.Printf("vpnpanel слушает %s", cfg.Listen)
	log.Fatal(http.ListenAndServe(cfg.Listen, mux))
}
