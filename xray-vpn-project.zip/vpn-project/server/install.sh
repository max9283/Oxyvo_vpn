#!/usr/bin/env bash
# Установка Xray (VLESS + Reality) и панели vpnpanel на Ubuntu/Debian.
# Запуск от root:  bash install.sh your.domain.or.ip
# Бинарник панели (vpnpanel) должен лежать рядом со скриптом (берётся из GitHub Actions).
set -euo pipefail

HOST="${1:?Укажите домен или IP сервера: bash install.sh example.com}"
SNI="${SNI:-www.microsoft.com}"
PORT=443

if [ "$(id -u)" -ne 0 ]; then echo "Запустите от root"; exit 1; fi
[ -f ./vpnpanel ] || { echo "Нет файла ./vpnpanel рядом со скриптом"; exit 1; }

apt-get update -y && apt-get install -y curl ca-certificates

# Официальный установщик Xray
bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install

# Ключи Reality (поддерживаем старый и новый формат вывода x25519)
KEYS="$(/usr/local/bin/xray x25519)"
PRIV="$(echo "$KEYS" | grep -i 'private' | awk '{print $NF}')"
PUB="$(echo "$KEYS" | grep -iE 'public|password' | awk '{print $NF}')"
SID="$(head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n')"
ADMIN="$(head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n')"

cat > /usr/local/etc/xray/config.json <<EOF
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "tag": "vless-in",
      "port": ${PORT},
      "protocol": "vless",
      "settings": { "clients": [], "decryption": "none" },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "${SNI}:443",
          "xver": 0,
          "serverNames": ["${SNI}"],
          "privateKey": "${PRIV}",
          "shortIds": ["${SID}"]
        }
      },
      "sniffing": { "enabled": true, "destOverride": ["http", "tls", "quic"] }
    }
  ],
  "outbounds": [
    { "protocol": "freedom", "tag": "direct" },
    { "protocol": "blackhole", "tag": "block" }
  ]
}
EOF

mkdir -p /etc/vpnpanel
cat > /etc/vpnpanel/settings.json <<EOF
{
  "listen": "127.0.0.1:8080",
  "admin_token": "${ADMIN}",
  "host": "${HOST}",
  "port": ${PORT},
  "public_key": "${PUB}",
  "short_id": "${SID}",
  "sni": "${SNI}",
  "xray_config": "/usr/local/etc/xray/config.json",
  "users_file": "/etc/vpnpanel/users.json",
  "xray_service": "xray"
}
EOF
chmod 600 /etc/vpnpanel/settings.json

install -m 755 ./vpnpanel /usr/local/bin/vpnpanel
cat > /etc/systemd/system/vpnpanel.service <<EOF
[Unit]
Description=VPN key panel
After=network.target

[Service]
ExecStart=/usr/local/bin/vpnpanel /etc/vpnpanel/settings.json
Restart=always
User=root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now xray vpnpanel

echo
echo "Готово."
echo "Админ-токен: ${ADMIN}   (сохранён в /etc/vpnpanel/settings.json)"
echo "Создать ключ:"
echo "  curl -X POST -H 'Authorization: Bearer ${ADMIN}' -d '{\"name\":\"user1\"}' http://127.0.0.1:8080/api/users"
echo "Панель слушает только localhost — для доступа снаружи используйте SSH-туннель."
