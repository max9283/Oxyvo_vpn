package com.example.xrayvpn

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var linkInput: EditText
    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.TOP
        }

        linkInput = EditText(this).apply {
            hint = "vless://..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            setText(getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("link", ""))
        }
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        status = TextView(this).apply { textSize = 16f; setPadding(0, pad, 0, 0) }

        root.addView(linkInput)
        root.addView(toggle)
        root.addView(status)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        toggle.text = if (VpnSvc.running) "Отключить" else "Подключить"
        status.text = when {
            VpnSvc.running -> "Подключено"
            VpnSvc.lastError != null -> "Ошибка: ${VpnSvc.lastError}"
            else -> "Отключено"
        }
    }

    private fun onToggle() {
        if (VpnSvc.running) {
            startService(Intent(this, VpnSvc::class.java).setAction(VpnSvc.ACTION_STOP))
            toggle.postDelayed({ refresh() }, 500)
            return
        }
        getSharedPreferences("prefs", Context.MODE_PRIVATE)
            .edit().putString("link", linkInput.text.toString().trim()).apply()

        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            @Suppress("DEPRECATION")
            startActivityForResult(prepare, REQ_VPN)
        } else {
            startVpn()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val i = Intent(this, VpnSvc::class.java)
            .putExtra(VpnSvc.EXTRA_LINK, linkInput.text.toString().trim())
        startService(i)
        toggle.postDelayed({ refresh() }, 1000)
    }

    companion object {
        const val REQ_VPN = 1
    }
}
