package com.example.xrayvpn

import android.content.Intent
import android.net.VpnService
import android.util.Log
import vpncore.Vpncore

class VpnSvc : VpnService() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        val link = intent?.getStringExtra(EXTRA_LINK)
        if (link == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startVpn(link)
        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка запуска", e)
            lastError = e.message ?: e.toString()
            stopVpn()
        }
        return START_NOT_STICKY
    }

    private fun startVpn(link: String) {
        lastError = null
        val config = VlessLink.toXrayConfig(link)

        val tun = Builder()
            .setSession("Xray VPN")
            .setMtu(MTU)
            .addAddress("10.10.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDisallowedApplication(packageName) // трафик самого ядра идёт мимо туннеля
            .establish() ?: throw IllegalStateException("Не удалось создать TUN")

        // detachFd: дескриптор дальше принадлежит Go-ядру
        Vpncore.start(config, tun.detachFd().toLong(), MTU.toLong())
        running = true
    }

    private fun stopVpn() {
        try {
            Vpncore.stop()
        } catch (_: Throwable) {
        }
        running = false
        stopSelf()
    }

    override fun onRevoke() {
        stopVpn()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    companion object {
        const val TAG = "VpnSvc"
        const val ACTION_STOP = "com.example.xrayvpn.STOP"
        const val EXTRA_LINK = "link"
        const val MTU = 1500

        @Volatile var running = false
        @Volatile var lastError: String? = null
    }
}
