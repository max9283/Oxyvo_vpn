package com.example.xrayvpn

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Разбор ссылки vless://UUID@host:port?...#name и сборка JSON-конфига Xray-клиента. */
object VlessLink {

    fun toXrayConfig(link: String): String {
        val uri = Uri.parse(link.trim())
        require(uri.scheme == "vless") { "Ссылка должна начинаться с vless://" }
        val uuid = requireNotNull(uri.userInfo) { "Нет UUID" }
        val host = requireNotNull(uri.host) { "Нет адреса сервера" }
        val port = if (uri.port > 0) uri.port else 443

        fun p(name: String, def: String = "") = uri.getQueryParameter(name) ?: def

        val user = JSONObject()
            .put("id", uuid)
            .put("encryption", "none")
            .put("flow", p("flow"))

        val stream = JSONObject().put("network", p("type", "tcp"))
        when (p("security")) {
            "reality" -> stream.put("security", "reality").put(
                "realitySettings", JSONObject()
                    .put("serverName", p("sni"))
                    .put("fingerprint", p("fp", "chrome"))
                    .put("publicKey", p("pbk"))
                    .put("shortId", p("sid"))
            )
            "tls" -> stream.put("security", "tls").put(
                "tlsSettings", JSONObject()
                    .put("serverName", p("sni", host))
                    .put("fingerprint", p("fp", "chrome"))
            )
        }

        val outbound = JSONObject()
            .put("tag", "proxy")
            .put("protocol", "vless")
            .put(
                "settings", JSONObject().put(
                    "vnext", JSONArray().put(
                        JSONObject()
                            .put("address", host)
                            .put("port", port)
                            .put("users", JSONArray().put(user))
                    )
                )
            )
            .put("streamSettings", stream)

        val inbound = JSONObject()
            .put("tag", "socks-in")
            .put("listen", "127.0.0.1")
            .put("port", 10808)
            .put("protocol", "socks")
            .put("settings", JSONObject().put("udp", true).put("auth", "noauth"))
            .put("sniffing", JSONObject()
                .put("enabled", true)
                .put("destOverride", JSONArray().put("http").put("tls").put("quic")))

        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("inbounds", JSONArray().put(inbound))
            .put("outbounds", JSONArray().put(outbound))
            .toString()
    }
}
